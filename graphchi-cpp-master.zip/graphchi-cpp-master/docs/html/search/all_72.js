var searchData=
[
  ['randomize',['randomize',['../structvertex__data.html#a4caa51a3710a504d31089b0865bb626d',1,'vertex_data']]],
  ['read_5fnext_5fvertices',['read_next_vertices',['../classgraphchi_1_1sliding__shard.html#a03c71ac33471a3239b63ce5e7033f08d',1,'graphchi::sliding_shard']]],
  ['read_5foutedges',['read_outedges',['../classgraphchi_1_1functional__vertex__unweighted__bulksync.html#a061aee312fc67647fe56c4acd87fc6ee',1,'graphchi::functional_vertex_unweighted_bulksync']]],
  ['readquerystring',['readQueryString',['../classmongoose_1_1_mongoose_request.html#ad6d55d79248cb560ffdecace8937e76b',1,'mongoose::MongooseRequest']]],
  ['refcountptr',['refcountptr',['../structgraphchi_1_1refcountptr.html',1,'graphchi']]],
  ['release_5fprior_5fto_5foffset',['release_prior_to_offset',['../classgraphchi_1_1sliding__shard.html#a9b8e6ee8b170b069aa250d8e6d2c266f',1,'graphchi::sliding_shard']]],
  ['residual',['residual',['../structvertex__data.html#a89b8e42b50a16c7c49a1c76b5b319853',1,'vertex_data']]],
  ['rmse',['rmse',['../als_8hpp.html#a4a31cf557efa8c68c5c0a73a5405ba3f',1,'als.hpp']]],
  ['role',['role',['../structedge__data.html#a3fbba49eb9690a4fdeeda275d6c9cad9',1,'edge_data']]],
  ['run',['run',['../classgraphchi_1_1graphchi__engine.html#a41254a769f3b0367b08f48bf2e16aa86',1,'graphchi::graphchi_engine']]],
  ['run_5ffunctional_5funweighted_5fsemisynchronous',['run_functional_unweighted_semisynchronous',['../namespacegraphchi.html#a70ac542b16515cd1f5e4bcdb4726ce1f',1,'graphchi']]],
  ['run_5ffunctional_5funweighted_5fsynchronous',['run_functional_unweighted_synchronous',['../namespacegraphchi.html#abc244c04632c39d92dd3e16916da6bb9',1,'graphchi']]],
  ['rwlock',['rwlock',['../classgraphchi_1_1rwlock.html',1,'graphchi']]]
];
