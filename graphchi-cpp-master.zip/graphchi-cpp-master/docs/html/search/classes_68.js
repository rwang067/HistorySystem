var searchData=
[
  ['html_5freporter',['html_reporter',['../classgraphchi_1_1html__reporter.html',1,'graphchi']]]
];
