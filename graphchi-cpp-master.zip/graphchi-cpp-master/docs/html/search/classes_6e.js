var searchData=
[
  ['null_5freporter',['null_reporter',['../classgraphchi_1_1null__reporter.html',1,'graphchi']]],
  ['null_5fstream',['null_stream',['../structnull__stream.html',1,'']]]
];
