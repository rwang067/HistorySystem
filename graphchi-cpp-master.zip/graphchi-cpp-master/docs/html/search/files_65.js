var searchData=
[
  ['edgebuffers_2ehpp',['edgebuffers.hpp',['../edgebuffers_8hpp.html',1,'']]]
];
