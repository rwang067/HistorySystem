library(testthat)
library(FlashR)

test_package("FlashR")
