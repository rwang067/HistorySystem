library(testthat)
library(FlashR)

test_file("Rpkg/inst/tests/test_dense.R")
