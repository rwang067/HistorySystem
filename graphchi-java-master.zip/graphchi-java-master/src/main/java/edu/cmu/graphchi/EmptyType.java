package edu.cmu.graphchi;

/**
 * Placeholder for vertex and edge data types that are 'empty'
 * @author Aapo Kyrola
 */
public class EmptyType {
}
