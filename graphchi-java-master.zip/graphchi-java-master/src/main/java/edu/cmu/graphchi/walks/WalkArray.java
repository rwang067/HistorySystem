package edu.cmu.graphchi.walks;

public abstract class WalkArray {
    public abstract int size();
}
