------
Disk management specification
--------

This folder tells you how to mount those disks and distribute your datasets on those disks

---
Structure
---

- **format_mount.bash**: format and mount disks.
- **remount.bash**: remount disk after such as reboot the system.
- **distribute.bash**: distribute data to mounted disks
