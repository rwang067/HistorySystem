#ifndef __UTIL_H__
#define __UTIL_H__

typedef long index_t;
typedef unsigned vertex_t;
typedef unsigned char sa_t;
typedef unsigned char bit_t;
typedef unsigned int comp_t;

#define INFTY 				255
#endif
